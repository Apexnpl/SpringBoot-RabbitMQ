package com.xyb.my_spring_boot_topic_productor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootTopicProductorApplicationTests {

	@Test
	void contextLoads() {
	}

}
