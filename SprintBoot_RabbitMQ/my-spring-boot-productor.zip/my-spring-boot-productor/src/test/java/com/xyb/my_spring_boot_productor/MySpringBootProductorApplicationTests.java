package com.xyb.my_spring_boot_productor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootProductorApplicationTests {

	@Test
	void contextLoads() {
	}

}
