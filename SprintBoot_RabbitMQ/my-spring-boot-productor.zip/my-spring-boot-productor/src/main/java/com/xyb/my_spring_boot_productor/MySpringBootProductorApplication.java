package com.xyb.my_spring_boot_productor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootProductorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootProductorApplication.class, args);
	}

}
