package com.xyb.my_spring_boot_consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
