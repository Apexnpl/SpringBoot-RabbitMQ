package com.xyb.my_spring_boot_topic_consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootTopicConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
